package br.univali.turma2502;

public interface Acessorio {
    void ativar(Personagem p);
}
