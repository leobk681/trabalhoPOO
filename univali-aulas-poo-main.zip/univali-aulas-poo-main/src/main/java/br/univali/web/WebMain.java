package br.univali.web;

import br.univali.web.config.Configuration;
import io.javalin.Javalin;

public class WebMain {

    public static void main(String[] args) {
        new Configuration();
    }

}
