package br.univali.turma2501.aula14;

public interface RandomGenerator {
    int getRandomInt();
}
