package br.univali.turma2501.aula15.legacy;

public enum MeioPagamento {
    SALDO_CONTA, CREDITO, DEBITO, PIX;
}
