package br.univali.turma2501.aula02;

public class ArcoFlecha implements Atirador {

    @Override
    public void atirar() {
        System.out.println("atirando flechas!!!");
    }
    
}
