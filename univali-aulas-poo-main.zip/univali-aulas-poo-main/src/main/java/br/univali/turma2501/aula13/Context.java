package br.univali.turma2501.aula13;

public interface Context {
    String getUserInput();
    String getSegundoParametro();
}
