package br.univali.turma2501.aula09;

public enum Permissao {
    CONVIDADO,
    REGULAR,
    ADMIN
}
