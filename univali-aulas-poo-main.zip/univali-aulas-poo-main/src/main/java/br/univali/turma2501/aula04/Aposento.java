package br.univali.turma2501.aula04;

public class Aposento {

    private String nome;

    public Aposento(String nome) {
        this.nome = nome;
    }
}
