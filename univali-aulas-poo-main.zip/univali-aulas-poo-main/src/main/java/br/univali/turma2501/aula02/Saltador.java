package br.univali.turma2501.aula02;

public interface Saltador {
    void pular();
}
