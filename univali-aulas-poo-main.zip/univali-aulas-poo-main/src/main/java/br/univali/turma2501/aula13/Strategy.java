package br.univali.turma2501.aula13;

public interface Strategy {

    String buscarDividas(Context context);

}
