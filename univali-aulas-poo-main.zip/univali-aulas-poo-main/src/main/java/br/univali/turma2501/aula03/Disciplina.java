package br.univali.turma2501.aula03;

public class Disciplina {
    private String nome;

    public Disciplina(String nome) {
        this.nome = nome;
    }
}
